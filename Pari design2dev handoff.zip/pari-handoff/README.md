# Pari — Developer Handoff

**Brand:** Pari Credit Markets  
**Version:** 1.0 · June 2026  
**Status:** Design-locked for MVP

---

## Files in this package

| File | Purpose |
|---|---|
| `tokens.css` | All design tokens as CSS custom properties |
| `components.css` | Component styles — buttons, cards, inputs, badges, CLOB, table, nav |
| `logo.svg` | Master logo SVG (icon + sigmoid mark) |
| `spec.html` | Living component spec — open in browser to see everything rendered |
| `README.md` | This file |

---

## Quick Start

```html
<!-- 1. Import tokens first, then components -->
<link rel="stylesheet" href="pari-handoff/tokens.css">
<link rel="stylesheet" href="pari-handoff/components.css">

<!-- 2. Default is dark mode. For light mode: -->
<html data-theme="light">
```

For React / Next.js / Vite:
```js
// In your root layout or main.css
import './pari-handoff/tokens.css';
import './pari-handoff/components.css';
```

---

## Design Directions

Two component sets are provided. **Pick one and stick to it.**

### Direction A — The Analyst
> Institutional elegance. Bloomberg meets fine finance.

- Soft border-radius (`3–4px`)
- EB Garamond serif for headings and data values
- Sentence-case button labels
- Class prefix: `.pari-a-*`

**Use for:** investor-facing dashboards, portfolio views, reporting screens.

### Direction B — The Trader
> Terminal precision. Hyperliquid meets Bloomberg YAS.

- Sharp `1px` radius (near-zero)
- All-caps uppercase buttons and labels
- Dense spacing, monospaced feel
- Class prefix: `.pari-b-*`

**Use for:** trading interfaces, order entry, CLOB, live market data.

> You can mix A for layout/navigation and B for trading widgets within one page.
> The shared tokens ensure colors and spacing stay consistent across both.

---

## Theming

Tokens are defined for both dark and light mode. Dark is the default.

```html
<!-- Dark (default) -->
<html>                        <!-- or data-theme="dark" -->

<!-- Light -->
<html data-theme="light">
```

To toggle in JavaScript:
```js
document.documentElement.dataset.theme = isDark ? 'dark' : 'light';
```

All color tokens automatically swap — no component code changes needed.

---

## Color Usage Rules

| Token | Use for |
|---|---|
| `--color-bg` | Page / app background |
| `--color-surface-1` | Cards, panels, modals |
| `--color-surface-2` | Input backgrounds, nested elements |
| `--color-surface-3` | Hover states, selected rows |
| `--color-teal` | Primary brand actions, links, highlights |
| `--color-text-1` | Primary body text |
| `--color-text-2` | Secondary/supporting text |
| `--color-text-muted` | Captions, placeholders, timestamps |
| `--color-danger` | Upbet, error states, destructive actions |
| `--color-success` | Positive P&L, confirmations |
| `--color-warning` | Margin warnings, pending states |
| `--border-brand` | Card and input borders (default) |
| `--border-subtle` | Dividers, row separators |

**Do not hardcode hex values in component code.** Always use the token. This ensures light/dark mode works correctly and makes future rebrands trivial.

---

## Typography Rules

```css
/* Headings, data values, display numbers → serif */
font-family: var(--font-serif);   /* EB Garamond */

/* All UI text: labels, buttons, body, inputs → sans */
font-family: var(--font-sans);    /* Barlow */
```

### Type scale

| Token | Size | Use |
|---|---|---|
| `--text-xs` | 11px | Labels, tags, all-caps eyebrows |
| `--text-sm` | 13px | Body small, table data |
| `--text-base` | 14px | Default UI body |
| `--text-lg` | 20px | Subtitles, lead text |
| `--text-xl` | 24px | Card headings (sans) |
| `--text-3xl` | 36px | Section headings |
| `--text-4xl` | 48px | Serif data display |
| `--text-5xl` | 64px | Hero headings |

### All-caps labels
Labels, eyebrows, badge text, and column headers are always:
```css
font-size: var(--text-xs);
font-weight: var(--weight-bold);          /* 700 */
letter-spacing: var(--tracking-widest);   /* 0.22em */
text-transform: uppercase;
color: var(--color-teal);                 /* or --color-text-muted for secondary */
```

---

## Component Reference

### Buttons

```html
<!-- Direction A -->
<button class="pari-a-btn pari-a-btn--primary">Trade Now</button>
<button class="pari-a-btn pari-a-btn--secondary">View Market</button>
<button class="pari-a-btn pari-a-btn--danger">Upbet</button>
<button class="pari-a-btn pari-a-btn--primary pari-a-btn--sm">Small</button>
<button class="pari-a-btn pari-a-btn--primary pari-a-btn--lg">Large</button>

<!-- Direction B -->
<button class="pari-b-btn pari-b-btn--primary">TRADE NOW</button>
<button class="pari-b-btn pari-b-btn--secondary">VIEW</button>
<button class="pari-b-btn pari-b-btn--danger">UPBET</button>
```

### Cards

```html
<!-- Direction A: Market card -->
<div class="pari-a-card">
  <div class="pari-a-card__eyebrow">Senior Unsecured · Jun 2026</div>
  <div class="pari-a-card__title">Microstrategy</div>
  <div class="pari-a-card__value">50.2%</div>
  <div class="pari-a-card__meta">Implied yield 10.4%</div>
</div>

<!-- Upbet / Downbet variants -->
<div class="pari-a-card pari-a-card--upbet">...</div>
<div class="pari-a-card pari-a-card--downbet">...</div>

<!-- Direction B: Terminal card -->
<div class="pari-b-card">
  <div class="pari-b-card__header">MSTR · JUN 2026</div>
  <div class="pari-b-card__value">50.2%</div>
  <div class="pari-b-card__sub">YLD 10.4% · $2.4M NOTIONAL</div>
</div>
```

### Badges

```html
<span class="pari-badge pari-badge--teal">Downbet</span>
<span class="pari-badge pari-badge--danger">Upbet</span>
<span class="pari-badge pari-badge--neutral">Pending</span>
<span class="pari-badge pari-badge--success">Settled</span>
<span class="pari-badge pari-badge--warning">Margin Call</span>
```

### Inputs

```html
<!-- Direction A -->
<div class="pari-a-field">
  <label class="pari-a-label">Notional Amount (USDC)</label>
  <input class="pari-a-input" placeholder="50,000" type="text">
  <span class="pari-a-hint">Min $1,000</span>
</div>

<!-- Error state -->
<input class="pari-a-input pari-a-input--error" ...>
<span class="pari-a-hint pari-a-hint--error">Insufficient balance</span>

<!-- Direction B -->
<div class="pari-b-field">
  <label class="pari-b-label">Notional (USDC)</label>
  <input class="pari-b-input" placeholder="50,000" type="text">
</div>
```

### CLOB Order Book (Direction B)

```html
<!-- Set --clob-cols on the container to control column widths -->
<div class="pari-clob" style="--clob-cols: 90px 1fr 70px">
  <div class="pari-clob__header">
    <span>Price (DP%)</span>
    <span>Notional</span>
    <span>Type</span>
  </div>
  <div class="pari-clob__row pari-clob__row--upbet">
    <span>51.0%</span><span>$500K</span><span>—</span>
  </div>
  <div class="pari-clob__mid">
    <span>50.2%</span><span>Market · Yld 10%</span><span></span>
  </div>
  <div class="pari-clob__row pari-clob__row--downbet">
    <span>50.1%</span><span>$100K</span><span>MM</span>
  </div>
</div>
```

### Table

```html
<table class="pari-table">
  <thead>
    <tr>
      <th>Market</th>
      <th data-numeric>Price</th>
      <th data-numeric>Notional</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <td>Microstrategy · Jun 2026</td>
      <td data-numeric>50.2%</td>
      <td data-numeric>$2.4M</td>
    </tr>
  </tbody>
</table>
```

### Nav

```html
<nav class="pari-nav">
  <a class="pari-wordmark" href="/">
    <!-- inline logo.svg here, sized 26x26 -->
    <span class="pari-wordmark__text">Pari</span>
  </a>
  <!-- your nav links -->
</nav>
```

---

## Logo Usage

See `logo.svg`. Key rules:

- **Clear space:** minimum ½ icon-height on all sides
- **Minimum size:** 24px tall for icon-only; 80px wide for full lockup
- **On dark background:** `stroke="#00C4B4"` (teal-400)
- **On light background:** `stroke="#009990"` (teal-500, higher contrast)
- **On teal background:** `stroke="rgba(0,0,0,0.65)"` (dark contrast)
- **Never** stretch, rotate, or recolor outside the three approved variants above
- The blinking midpoint dot is an animation for web only — omit in print/export

---

## Do's and Don'ts

### Do
- Use tokens for every color, size, and spacing value
- Keep dark mode as the primary trading UI; light for docs/marketing
- Use EB Garamond for all numeric data values (it's the brand's financial voice)
- Apply `font-variant-numeric: tabular-nums` on all price/number columns

### Don't
- Hardcode hex colors in component CSS
- Mix Direction A and Direction B **within the same widget** (it's fine across page sections)
- Use gradients on backgrounds — flat surfaces only
- Use emoji anywhere in the UI
- Use Inter, Roboto, or Arial — these are explicitly off-brand

---

## Spacing & Layout Notes

- Use `display: flex` / `display: grid` with `gap` for all multi-item layouts
- Content max-width: `1280px` centered, `52px` horizontal padding on desktop
- Cards have internal padding of `var(--space-6)` (24px) by default
- Table row height is ~40px; CLOB rows are dense at ~28px

---

## Questions?
Reference the full brand guidelines at `Pari Brand Guidelines.html` in the design project.
